import $ from 'jquery';
import { api } from '../config';

const
  defaultHeaders = {
    'content-type': 'application/json; charset=utf-8',
  },
  post = (url, headers, data, done, callbackSuccess, callbackError, dispatch, getState, auth = true) => {
    /* eslint-disable one-var */
    headers = headers || defaultHeaders;
    if (!auth) {
      const
      { user } = getState().signin;
      headers['x-access-token'] = user.token;
    }
    const settings = {
      'async': true,
      'crossDomain': true,
      'url': `${api.root}${url}`,
      'method': 'POST',
      headers,
      data: JSON.stringify(data),
    };
    /* eslint-enable one-var */

    $.ajax(settings)
    .done((response) => {
      dispatch(done(response));
      if (callbackSuccess) callbackSuccess(response);
    })
    .fail((error) => {
      dispatch(done());
      if (callbackError) callbackError(error);
    });
  },
  get = (url, headers, data, done, callbackSuccess, callbackError, dispatch, getState, auth = true) => {
    /* eslint-disable one-var */
    headers = headers || defaultHeaders;
    if (!auth) {
      const
      { user } = getState().signin;
      headers['x-access-token'] = user.token;
    }
    const settings = {
      'async': true,
      'crossDomain': true,
      'url': `${api.root}${url}`,
      'method': 'GET',
      headers,
    };
    /* eslint-enable one-var */

    $.ajax(settings)
    .done((response) => {
      dispatch(done(response));
      if (callbackSuccess) callbackSuccess(response);
    })
    .fail((error) => {
      dispatch(done());
      if (callbackError) callbackError(error);
    });
  };

export default {
  post,
  get,
};
