import mirrorkey from 'mirrorkey';

export default mirrorkey([
  'GET_PAGES',
]);
