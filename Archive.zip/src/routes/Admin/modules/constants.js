import mirrorkey from 'mirrorkey';

export default mirrorkey([
  'SET_PAGES',
  'GET_QUESTIONS_BEGIN',
  'GET_QUESTIONS_END',
]);
