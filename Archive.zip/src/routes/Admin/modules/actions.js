import Constants from './constants';
import http from '../../../utils/http';

const
  setPages = (payload = []) => {
    sessionStorage.setItem('pages', JSON.stringify(payload));
    return {
      type: Constants.SET_PAGES,
    };
  },

  getQuestionsBegin = () => {
    return {
      type: Constants.GET_QUESTIONS_BEGIN,
    };
  },

  getQuestionsEnd = (payload = null) => {
    return {
      type: Constants.GET_QUESTIONS_END,
      payload,
    };
  },

  getQuestions = (payload, callbackSuccess, callbackFailure) => {
    return (dispatch, getState) => {
      dispatch(getQuestionsBegin());
      return http.get(
          `/api/question/list`,
          null,
          payload,
          getQuestionsEnd,
          callbackSuccess,
          callbackFailure,
          dispatch,
          getState
      );
    };
  };

export default {
  setPages,
  getQuestions,
};
